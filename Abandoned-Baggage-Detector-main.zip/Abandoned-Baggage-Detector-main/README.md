 Abandoned Baggage Detector:
 this is a python project made with the latest version of YOLO V9
